function hh=xbbh(F,m,n,d1,d2)
%~~~~~�б任
for i=1:m
    for j=1:n
        if j<n
        h0(i,j)=[F(i,j),F(i,j+1)]*d1;
        else
        h0(i,j)=[F(i,j),F(i,1)]*d1;
        end
    end
end

hh0=h0(:,1:2:n); %ȡ��
 if mod(n,2)==0  %����С���任�������n=length(hh0)
    n=n/2;
else
    n=(n+1)/2;
 end  
 %~~~~~~~�б任
for i=1:m
    for j=1:n
        if i<m
        h00(i,j)=[hh0(i,j),hh0(i+1,j)]*d2;
        else
        h00(i,j)=[hh0(i,j),hh0(1,j)]*d2; 
        end
    end
end
hh=h00(1:2:m,:);%ȡ��   
        
    

